package net.mcreator.reloaded.block.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.reloaded.block.display.DefectivePanelDisplayItem;

public class DefectivePanelDisplayModel extends AnimatedGeoModel<DefectivePanelDisplayItem> {
	@Override
	public ResourceLocation getAnimationResource(DefectivePanelDisplayItem animatable) {
		return new ResourceLocation("reloaded", "animations/defective_panel.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(DefectivePanelDisplayItem animatable) {
		return new ResourceLocation("reloaded", "geo/defective_panel.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(DefectivePanelDisplayItem entity) {
		return new ResourceLocation("reloaded", "textures/blocks/panel.png");
	}
}
