package net.mcreator.reloaded.block.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.reloaded.block.entity.DefectivePanelTileEntity;

public class DefectivePanelBlockModel extends AnimatedGeoModel<DefectivePanelTileEntity> {
	@Override
	public ResourceLocation getAnimationResource(DefectivePanelTileEntity animatable) {
		return new ResourceLocation("reloaded", "animations/defective_panel.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(DefectivePanelTileEntity animatable) {
		return new ResourceLocation("reloaded", "geo/defective_panel.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(DefectivePanelTileEntity entity) {
		return new ResourceLocation("reloaded", "textures/blocks/panel.png");
	}
}
